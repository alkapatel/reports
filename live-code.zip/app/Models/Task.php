<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
	public $timestamps = true;
    protected $table = TBL_TASK;

    /**
     * @var array
     */
    protected $fillable = ['id','title','description','total_time','','status','project_id','ref_link','user_id','task_date'];

    public function Project()
    {
        return $this->hasMany('App\Models\Project');
    }
	public static function listFilter($query)
    {
        $search_start_date = request()->get("search_start_date");
        $search_end_date = request()->get("search_end_date");                                
        $search_id = request()->get("search_id");                                
        $search_project = request()->get("search_project");                                
        $search_title = request()->get("search_title");                                
        $search_status = request()->get("search_status");                            
        $search_user = request()->get("search_user");
        $search_client = request()->get("search_client");
        $search_hour = request()->get("search_hour");                                
        $search_hour_op = request()->get("search_hour_op");                                
        $search_min = request()->get("search_min");
        $search_min_op = request()->get("search_min_op");
		$is_download = request()->get("isDownload");

        if(!empty($search_hour) && empty($search_min))
        {
            $search_min ='0.00';   
        }
        else if(empty($search_hour) && !empty($search_min))
        {
            $search_hour = '0.00';
        } 
        if (!empty($search_start_date)){

            $from_date=$search_start_date.' 00:00:00';
            $convertFromDate= $from_date;

            $query = $query->where(TBL_TASK.".task_date",">=",addslashes($convertFromDate));
        }
        if (!empty($search_end_date)){

            $to_date=$search_end_date.' 23:59:59';
            $convertToDate= $to_date;

            $query = $query->where(TBL_TASK.".task_date","<=",addslashes($convertToDate));
        }
        if(!empty($search_id))
        {
            $idArr = explode(',', $search_id);
            $idArr = array_filter($idArr);                
            if(count($idArr)>0)
            {
                $query = $query->whereIn(TBL_TASK.".id",$idArr);
            } 
        }
        if(!empty($search_project))
        {
            $query = $query->where(TBL_TASK.".project_id", $search_project);
        }
        if(!empty($search_client))
        {
            $query = $query->where(TBL_PROJECT.".client_id", $search_client);
        }
        if(!empty($search_title))
        {
            $query = $query->where(TBL_TASK.".title", 'LIKE', '%'.$search_title.'%');
        }
        if (!empty($search_hour)) {
               $query = $query->where(TBL_TASK.".hour", $search_hour_op, $search_hour);
        }
        if (!empty($search_min)) {
               $query = $query->where(TBL_TASK.".min", $search_min_op, $search_min);
        }
        if($search_status == "1" || $search_status == "0")
        {
            $query = $query->where(TBL_TASK.".status", $search_status);
        }
        if(!empty($search_user))
        {
            $query = $query->where(TBL_TASK.".user_id",$search_user);
        }
		if(!empty($is_download) && $is_download == 1)
        {
            $query = $query->limit(1000)->get();
        }

        return $query;
    }
}
