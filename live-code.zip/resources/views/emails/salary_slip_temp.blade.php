<h3>Hello {{$firstname}}  {{$lastname}}, </h3>
<p><b>{{$description}} .</b></p>
<p>
    <a href='{{$link}}'>click here to view salary slip.</a>
</p>