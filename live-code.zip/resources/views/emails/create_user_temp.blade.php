<h3>Hello {{$firstname}}  {{$lastname}}, </h3>
<p>Your account has been created successfully.</p>
<p>Below are your login details:</p><hr/>
<p>
    <span>Email: <b>{{$email}}</b></span>
</p>
<p>
    <span>Password: <b>{{$password}}</b>
</p>
<p>
    <span>Link: <b>{{$link}}</b>
</p>
