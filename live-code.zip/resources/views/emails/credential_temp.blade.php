<h3>Hello {{$name}}, </h3>
<p><b>{{$description}} .</b></p>
<p>
    <a href='{{$link}}'>click here to view credential.</a>
</p>