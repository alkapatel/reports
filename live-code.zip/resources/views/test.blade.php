


<html>
	<body>
	<div>
		<b>From Date:</b> 01 oct 2017 <br/> 
		<b>To Date:</b> 05 oct 2017 
		<br/><br/>
		<span>Dear Perl, </span>
		<p>
			I am writing this letter to officially inform you that I will not be able to attend office for two days, as I need to be in person for selling my land to a buyer in the outskirts of the city.
		</p>
		<span>Thanking You,</span><br/><br/>
		<span>Yours Sincerely,</span><br/>
		<span>Donald T. Proctor</span><br/>
	
	</div>
	<body>
</html>