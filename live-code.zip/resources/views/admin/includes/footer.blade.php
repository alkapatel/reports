<!-- BEGIN INNER FOOTER -->
<div class="page-footer">
    <div class="container"> 
        {{ date('Y')}} &copy;  {{ env('APP_SITE_TITLE')}} ALL Rights Reserved.                
    </div>
</div>
<div class="scroll-to-top">
    <i class="icon-arrow-up"></i>
</div>
<!--=== End Copyright ===-->    

