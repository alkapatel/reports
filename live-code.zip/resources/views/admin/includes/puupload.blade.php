<?php /* due to js conflic add js here */?>
<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/themes/base/jquery-ui.css" type="text/css" />
<link rel="stylesheet" href="{{ asset('/')}}/thirdparty/plupload-2.1.2/js/jquery.ui.plupload/css/jquery.ui.plupload.css" type="text/css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="{{ asset('/')}}/thirdparty/plupload-2.1.2/js/plupload.full.min.js"></script>
<script type="text/javascript" src="{{ asset('/')}}/thirdparty/plupload-2.1.2/js/jquery.ui.plupload/jquery.ui.plupload.js"></script>

<style>
  .plupload_logo{display: none !important;}
  #sortable { list-style-type: none; margin: 0; padding: 0; width: auto; }
  #sortable li { margin: 3px 20px 3px 5px; padding: 1px; float: left; width: 110px; height: 140px; text-align: center; background: #ffffff }
  #sortable li img{ max-height: 100px; max-width: 100px; margin-top: 8px}
  .white-font{color: #FFFFFF !important;}
</style>
