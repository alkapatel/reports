 
 @foreach($views as $view)
<div class="portlet blue-hoki box">
	<div class="portlet-title">
		<div class="caption">
		<i class="fa fa-user"></i>Credential </div>
	</div>
	<div class="portlet-body">
		<div class="row static-info">
			<div class="col-md-5 name"> Project: </div>
			<div class="col-md-7 value"> {{$view->project_name}} </div>
		</div>
		<div class="row static-info">
			<div class="col-md-5 name"> Environment: </div>
			<div class="col-md-7 value"> {{$view->environment}}</div>
		</div>
		<div class="row static-info">
			<div class="col-md-5 name"> Protocol: </div>
			<div class="col-md-7 value"> {{$view->protocol}} </div>
		</div>
		@if($view->protocol == 'FTP' || $view->protocol == 'SSH')
		<div class="row static-info">
			<div class="col-md-5 name"> Host Name: </div>
			<div class="col-md-7 value"> {{$view->hostname}} </div>
		</div>
		@endif
		@if($view->protocol == 'FTP' || $view->protocol == 'CPANEL' || $view->protocol == 'SSH' || $view->protocol == 'ADMIN/WP-ADMIN' || $view->protocol == 'FRONT-END' || $view->protocol == 'HOSTING')
		<div class="row static-info">
			<div class="col-md-5 name"> User Name: </div>
			<div class="col-md-7 value"> {{$view->username}}</div>
		</div>
		@endif
		@if($view->protocol == 'FTP' || $view->protocol == 'CPANEL' || $view->protocol == 'SSH' || $view->protocol == 'ADMIN/WP-ADMIN' || $view->protocol == 'FRONT-END' || $view->protocol == 'HOSTING')
		<div class="row static-info">
			<div class="col-md-5 name"> Password: </div>
			<div class="col-md-7 value"> {{$view->password}}</div>
		</div>
		@endif
		@if($view->protocol == 'FTP' || $view->protocol == 'SSH')
		<div class="row static-info">
			<div class="col-md-5 name"> Port: </div>
			<div class="col-md-7 value"> {{$view->port}}</div>
		</div>
		@endif
		@if($view->protocol == 'CPANEL' || $view->protocol == 'ADMIN/WP-ADMIN' || $view->protocol == 'FRONT-END' || $view->protocol == 'HOSTING')
		<div class="row static-info">
			<div class="col-md-5 name"> URL: </div>
			<div class="col-md-7 value"> {{$view->url}}</div>
		</div>
		@endif
		@if($view->protocol == 'SSH')
		<div class="row static-info">
			<div class="col-md-5 name"> Key File: </div>
			<div class="col-md-7 value"> {{$view->key_file}}   
				@if($view->key_file != '')
				<a class='btn btn-xs btn-warning' href='{{ asset("/credentials/download/$view->id") }}' > Download </a>
				@endif
			</div>
		</div>
		@endif
		@if($view->protocol == 'SSH')
		<div class="row static-info">
			<div class="col-md-5 name"> Key File Password: </div>
			<div class="col-md-7 value"> {{$view->key_file_password}}</div>
		</div>
		@endif
		@if($view->protocol == 'EXTRA')
		<div class="row static-info">
			<div class="col-md-5 name"> Title: </div>
			<div class="col-md-7 value"> {{$view->title}}</div>
		</div>
		<div class="row static-info">
			<div class="col-md-5 name"> Description: </div>
			<div class="col-md-7 value"> {{$view->description}}</div>
		</div>
		@endif
	</div>
</div>
@endforeach