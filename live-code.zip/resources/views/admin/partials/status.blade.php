@if($status == 1)
	<a class="btn btn-xs btn-success">Active</a>
@else
	<a class="btn btn-xs btn-danger">Inactive</a>
@endif